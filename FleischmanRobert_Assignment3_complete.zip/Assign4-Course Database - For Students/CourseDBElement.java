/**
 * 
 */

/**
 * @param <T>
 * 
 */
public class CourseDBElement implements Comparable {
	public CourseDBElement(String iD, int cRN, int cnum, String roomnum, String instrname) {
		super();
		ID = iD;
		CRN = cRN;
		this.cnum = cnum;
		this.roomnum = roomnum;
		this.instrname = instrname;
	}

	private String ID;
	private int CRN;
	private int cnum;
	private String roomnum;
	private String instrname;

	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}

	/**
	 * @return the cRN
	 */
	public int getCRN() {
		return CRN;
	}

	/**
	 * @param cRN the cRN to set
	 */
	public void setCRN(int cRN) {
		CRN = cRN;
	}

	/**
	 * @return the cnum
	 */
	public int getCnum() {
		return cnum;
	}

	/**
	 * @param cnum the cnum to set
	 */
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}

	/**
	 * @return the roomnum
	 */
	public String getRoomNum() {
		return roomnum;
	}

	/**
	 * @param roomnum the roomnum to set
	 */
	public void setRoomnum(String roomnum) {
		this.roomnum = roomnum;
	}

	/**
	 * @return the instrname
	 */
	public String getInstrname() {
		return instrname;
	}

	/**
	 * @param instrname the instrname to set
	 */
	public void setInstrname(String instrname) {
		this.instrname = instrname;
	}

	@Override
	public int compareTo(Object o) {
		CourseDBElement or =(CourseDBElement)o;
		return -1* (this.ID+ (Integer.MAX_VALUE-this.CRN)).compareTo((or.ID+(Integer.MAX_VALUE-or.CRN)));
	}
	public String toString() {
		String s=  "Course:"+ID+" CRN:"+CRN+" Credits:"+cnum+" Instructor:"+instrname+" Room:" +roomnum;
		return s;
	}

}
