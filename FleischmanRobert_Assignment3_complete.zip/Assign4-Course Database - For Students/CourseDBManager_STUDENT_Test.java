import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CourseDBManager_STUDENT_Test {

	private CourseDBManagerInterface dataMgr = new CourseDBManager();

	/**
	 * Create an instance of CourseDBManager
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		dataMgr = new CourseDBManager();
	}

	/**
	 * Set dataMgr reference to null
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		dataMgr = null;
	}



	/**
	 * Test for the showAll method ensureing order is correct
	 */
	@Test
	public void testShowAll() {
		dataMgr.add("CMSC203",30504,4,"SC450","Joey Bag-O-Donuts");
		dataMgr.add("CMSC204",30503,4,"SC450","Jill B. Who-Dunit");
		dataMgr.add("CMSC205",30559,4,"SC450","BillyBob Jones");
		ArrayList<String> list = dataMgr.showAll();
		System.out.println(list.get(0)+list.get(1)+list.get(2));
		assertEquals(list.get(0),"\nCourse:CMSC205 CRN:30559 Credits:4 Instructor:BillyBob Jones Room:SC450");
		assertEquals(list.get(1),"\nCourse:CMSC204 CRN:30503 Credits:4 Instructor:Jill B. Who-Dunit Room:SC450");
		assertEquals(list.get(2),"\nCourse:CMSC203 CRN:30504 Credits:4 Instructor:Joey Bag-O-Donuts Room:SC450");
	}

	/**
	 * Test for the read method
	 */
}
