import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.stage.FileChooser;

public class CourseDBManager implements CourseDBManagerInterface {
	private CourseDBStructure cdbs= new CourseDBStructure(1000);
	public CourseDBManager() {

	}

	@Override
	/**
	 * Adds a course (CourseDBElement) with the given information
	 * to CourseDBStructure.
	 * @param id course id 
	 * @param crn course crn
	 * @param credits number of credits
	 * @param roomNum course room number
	 * @param instructor name of the instructor
	 */
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		cdbs.add(new CourseDBElement(id, crn, credits, roomNum, instructor));
		
	}

	@Override
	/**
	 * finds  CourseDBElement based on the crn key
	 * @param crn course crn (key)
	 * @return a CourseDBElement object
	 * 
	 */
	public CourseDBElement get(int crn) {
		try {
			return cdbs.get(crn);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

	@Override
	/**
	 * Reads the information of courses from a test file and adds them
	 * to the CourseDBStructure data structure
	 * @param input input file 
	 * @throws FileNotFoundException if file does not exists
	 */
	public void readFile(File input) throws FileNotFoundException {
		Scanner fr=new Scanner(input);
		while(fr.hasNext()) {
			String ne=fr.nextLine();
			String[] sar=ne.split(" ",5);
			add(sar[0],Integer.valueOf(sar[1]),Integer.valueOf(sar[2]),sar[3],sar[4]);
		}

	}

	@Override
	/**
	 * @return an array list of string representation of each course in 
	 * the data structure separated by a new line. 
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
	public ArrayList<String> showAll() {
		return cdbs.showAll();
	}

}
