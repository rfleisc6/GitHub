/**
 * 
 */

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;

/**
 * 
 */
public class CourseDBStructure implements CourseDBStructureInterface {
	private int siz;
	static final double FACT=1.5;
	ArrayList<LinkedList<CourseDBElement>> list;
	public CourseDBStructure(String tes,int size) {
		siz=size;
		list= new ArrayList<LinkedList<CourseDBElement>>(size);
		for(int i=0;i<siz;i++) {
			list.add(new LinkedList<CourseDBElement>());
		}
	}
	/**
	 * checks if p is prime 
	 * @param p
	 * @return
	 */
	public static boolean isprim(int p) {
		for(int i =2;i<p;i++) {
			if(p%i==0) {
				return false;
			}
		}
		return true;
	}
	public CourseDBStructure(int size) {
		int base= ((int)(((double) size)/FACT))/4;
		int s = 4*base+3;
		while(!isprim(s)) {
			s+=4;
		}
		siz=s;
		list= new ArrayList<LinkedList<CourseDBElement>>(s);
		for(int i=0;i<siz;i++) {
			list.add(new LinkedList<CourseDBElement>());
		}
	}

	@Override
	/** 
	* Adds a CourseDBElement object to the CourseDBStructure using the hashcode
	* of the CourseDatabaseElemen object's crn value.
	* If the CourseDatabaseElement already exists, exit quietly
	*  
	* @param element the CourseDBElement to be added to CourseDBStructure
	*/
	public void add(CourseDBElement element) {
		try {
			this.get(element.getCRN()) ;
			this.get(element.getCRN()).setCnum(element.getCnum());
			this.get(element.getCRN()).setID(element.getID());
			this.get(element.getCRN()).setInstrname(element.getInstrname());
			this.get(element.getCRN()).setRoomnum(element.getRoomNum());

			}
		catch (IOException e) {
			int hcode=(""+element.getCRN()).hashCode()%siz;
			if(list.get(hcode)==null) {
				list.set(hcode,new LinkedList<CourseDBElement>());		
			}
			list.get(hcode).addLast(element);			
		}
	}

	@Override
	/**
	 * Find a courseDatabaseElement based on the key (crn) of the
	 * courseDatabaseElement If the CourseDatabaseElement is found return it If not,
	 * throw an IOException
	 * 
	 * @param crn crn (key) whose associated courseDatabaseElement is to be returned
	 * @return a CourseDBElement whose crn is mapped to the key
	 * @throws IOException if key is not found
	 */

	public CourseDBElement get(int crn) throws IOException {
		int hcode=(""+crn).hashCode()%siz;;
		LinkedList<CourseDBElement> lis=list.get(hcode);
		for( CourseDBElement co : lis) {
			if(crn==co.getCRN()) {
				return co;
			}
		}
		throw new IOException();
	}

	@Override
	/**
	 * @return an array list of string representation of each course in 
	 * the data structure separated by a new line. 
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
	public ArrayList<String> showAll() {
		ArrayList<CourseDBElement> liss=new ArrayList<CourseDBElement>();
		ArrayList<String> l= new ArrayList<String>();
		for(LinkedList<CourseDBElement> lis : list) {
			if (!(lis==null)) {
				for(CourseDBElement co : lis) {
					liss.add(co);
				}
			}
		}
		liss.sort(null);
		for(CourseDBElement co : liss) {
			l.add("\n"+co.toString());
		}
		return l;

	}

	@Override
	/**
	* Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	*/
	public int getTableSize() {
		return siz;
	}

}
